## How to install project dependencies

### run `yarn install`

## How to run the project

In the project directory, you can run:

### `yarn start`

## Verification

Tested on Mac + Expo + Apple iPhone 11 Pro Max emulator