## Stage 1: Make a Web page
Webpages, Documents, and Structure
Built using HTML and CSS, this project demonstrates knowledge of basic website design, HTML
, CSS
, Structured documents
 and HTML classes

