## Stage 0 - Getting Started with HTML

This project demonstrates basic knowledge of the web and HTML.