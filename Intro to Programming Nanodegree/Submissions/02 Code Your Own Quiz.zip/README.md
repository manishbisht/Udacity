## Stage 2: Code Your Own Quiz
Mad Libs-Style game