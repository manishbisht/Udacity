# Movie Trailer Website

Run this program and see a list of latest bollywood favorite movies



## Make sure Python is installed


Open up your terminal and run:



$ python



It should return some version of Python like 2.7.



If Python is not installed at all, see the documentation here: https://www.python.org



## Run this Program

Navigate to the project folder and run:

$ python entertainment.py



A browser should open on your local machine and and render the HTML template with latest movies. Click on a movie thumbnail to view the trailer !

! Enjoy :)
