# Description

# Github Repository URL
- https://github.com/manishbisht/Udagram-Your-Own-Instagram-on-AWS

# Elastic BeanStalk URL
- http://udacity-cloud-p2-udagram-dev.ap-south-1.elasticbeanstalk.com

Example: `http://udacity-cloud-p2-udagram-dev.ap-south-1.elasticbeanstalk.com/filteredimage?image_url=https://timedotcom.files.wordpress.com/2019/03/kitten-report.jpg`