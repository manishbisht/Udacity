# Problem 6: Unsorted Integer Array

My implementation sets the initial min and max values as the first value in the array. It then iterates once through and adjusts them accordingly.

Time Complexity: O(n)

The array is iterated through once.

Space Complexity: O(1)

No additional memory is allocated.