import { handleSubmit } from './js/formHandler'

document.getElementById('processURLButton').addEventListener('click', handleSubmit)
